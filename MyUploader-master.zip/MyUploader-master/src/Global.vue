<script>
  const server_config = {
    url: 'http://192.168.30.117:9999/api/v1.0/File/Upload'
  };
  export default {
    server_config
  }
</script>

